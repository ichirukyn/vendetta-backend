export type entity_attribute = '';
