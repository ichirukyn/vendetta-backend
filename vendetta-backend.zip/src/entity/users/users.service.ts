import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { User } from './user.model';
import { CreateUserDto } from './dto/create-user.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Hero } from '../hero/hero.model';
import { SignInDto } from './dto/sign-in.dto';
import * as bcrypt from 'bcrypt';
import * as jwt from 'jsonwebtoken';
import { mainConfig } from '../../common/helpers/main.config';
import { RedisService } from '../../common/services/redis/redis.service';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User) private usersRepository: Repository<User>,
    @InjectRepository(Hero) private usersHeroRepository: Repository<Hero>,
    // private redisService: RedisService,
  ) {}
  
  async signIn(data: SignInDto) {
    let user = await this.usersRepository.findOneBy({ login: data.login });
    
    if (!(await bcrypt.compare(data.password, user.password))) {
      throw new InternalServerErrorException('Невернный пароль');
    }
    
    const token = jwt.sign({ chat_id: user.chat_id, login: user.login }, mainConfig.tokenSecret, {
      expiresIn: mainConfig.jwtLifeTime,
    });
    
    // await this.redisService.setExpiryData(
    //   `userToken:${ token }`,
    //   2592000,
    //   JSON.stringify({
    //     chat_id: user.chat_id,
    //     login: user.login,
    //   }),
    // );
    //
    return token;
  }
  
  
  async createUser(dto: CreateUserDto) {
    let user = this.usersRepository.create(dto);
    return await this.usersRepository.save(user);
  }
  
  async getUser(chat_id: string) {
    const user = await this.usersRepository.findOneBy({ chat_id: chat_id });
    
    if (!user) {
      throw new HttpException('Пользователь не найден', HttpStatus.BAD_REQUEST);
    }
    
    return user;
  }
  
  async getUserChatId(user_id: number) {
    const user = await this.usersRepository.findOneBy({ id: user_id });
    
    if (!user) {
      throw new HttpException('Пользователь не найден', HttpStatus.BAD_REQUEST);
    }
    
    return user.chat_id;
  }
  
  async getUsers() {
    return await this.usersRepository.find();
  }
  
  
  // Hero
  async getUserHero(user_id: number) {
    const hero = await this.usersHeroRepository.findOne({
      relations: ['user', 'race', 'class'],
      where: { user: { id: user_id } },
    });
    if (!hero) {
      throw new HttpException('Пользователь не найден', HttpStatus.BAD_REQUEST);
    }
    
    return hero;
  }
}
