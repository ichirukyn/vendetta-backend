import { Injectable } from '@nestjs/common';
import { RedisService } from './redis.service';

@Injectable()
export class CacheService<T> extends RedisService {
  private duration = 365 * 24 * 3600;
  prefix: string;
  prefixArray: string;

  constructor() {
    super();
  }

  setPrefix(prefix: string): void {
    this.prefix = prefix;
  }

  setPrefixId(prefixArray: string): void {
    this.prefixArray = prefixArray;
  }

  async set(key: string, data: T): Promise<boolean> {
    const value = JSON.stringify(data);
    return await this.setExpiryData(this.prefix + key, this.duration, value);
  }

  async get(key: string): Promise<T> {
    const data = await this.getByKey(this.prefix + key);
    const parsed = JSON.parse(data);
    return parsed as T;
  }

  async remove(key: string): Promise<number> {
    return await this.delete(this.prefix + key);
  }

  async getArray(key: string): Promise<string[]> {
    const data = await this.getArrayByKey(this.prefixArray + key);
    if (!data) return [];
    return data;
  }

  async setArray(key: string, values: string[]): Promise<boolean> {
    await this.push(this.prefixArray + key, values);
    return true;
  }

  async removeFromArray(arrayName: string, key: string): Promise<number> {
    return await this.deleteFromArray(arrayName, this.prefixArray + key);
  }

  async clearInvalidData(obj: T) {
    return Object.fromEntries(Object.entries(obj).filter(([, value]) => value !== undefined));
  }
}
