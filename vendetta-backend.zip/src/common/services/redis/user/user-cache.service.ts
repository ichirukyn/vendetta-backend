import { Injectable } from '@nestjs/common';
import { RedisService } from '../redis.service';
import { User } from '../../../../entity/users/user.model';

@Injectable()
export class UserCacheService extends RedisService {
  constructor() {
    super();
  }
  
  async cacheUserData(userData: User): Promise<boolean> {
    const key = `user:${ userData.id }`;
    return await this.set(key, JSON.stringify(userData));
  }
  
  async getCachedUserData(userId: string): Promise<User> {
    const key = `user:${ userId }`;
    const userDataString = await this.getByKey(key);
    return userDataString ? JSON.parse(userDataString) : null;
  }
  
  async deleteUserCache(userId: string): Promise<number> {
    const key = `user:${ userId }`;
    return await this.delete(key);
  }
  
  async update(userId: string, updateFields: User) {
    const user = await this.getCachedUserData(userId);
    const newUser = { ...user, ...updateFields };
    await this.cacheUserData(newUser);
  }
}
