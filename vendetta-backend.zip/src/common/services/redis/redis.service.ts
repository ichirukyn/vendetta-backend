import { Injectable } from '@nestjs/common';
import Redis from 'ioredis';
import { mainConfig } from '../../helpers/main.config';

@Injectable()
export class RedisService {
  private redisConnection: Redis;

  constructor() {
    this.redisConnection = new Redis({
      port: mainConfig.redis.port,
      host: mainConfig.redis.host,
      password: mainConfig.redis.password,
      db: 0,
    });
  }

  async push(arrayName: string, value: any): Promise<boolean> {
    await this.redisConnection.lpush(arrayName, value);
    return true;
  }

  async set(key: string, value: any): Promise<boolean> {
    await this.redisConnection.set(key, value);

    return true;
  }

  async setExpiryData(key: string, lifeTimeDurationSeconds: number, data: any): Promise<boolean> {
    await this.redisConnection.setex(key, lifeTimeDurationSeconds, data);

    return true;
  }

  async setExpireTime(key: string, lifeTimeDurationSeconds: number): Promise<boolean> {
    await this.redisConnection.expire(key, lifeTimeDurationSeconds);

    return true;
  }

  async getByKey(key: string): Promise<string> {
    try {
      return await this.redisConnection.get(key);
    } catch (error) {
      return null;
    }
  }

  async getArrayByKey(key: string): Promise<string[]> {
    try {
      return await this.redisConnection.lrange(key, 0, -1);
    } catch (error) {
      return null;
    }
  }
  async getTTL(key: string): Promise<number> {
    return await this.redisConnection.ttl(key);
  }

  async delete(key: string): Promise<number> {
    return await this.redisConnection.del(key);
  }

  async deleteFromArray(arrayName: string, key: string): Promise<number> {
    return await this.redisConnection.lrem(arrayName, 1, key);
  }
}
