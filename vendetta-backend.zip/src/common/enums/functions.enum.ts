export enum FunctionNames {
  HeroEdit = 'heroEdit',
}