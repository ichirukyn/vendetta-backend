export enum Order {
  ASC = 'ASC',
  DESC = 'DESC',
}