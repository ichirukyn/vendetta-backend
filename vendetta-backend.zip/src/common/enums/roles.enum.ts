export enum Roles {
  Admin = 'admin',
  Moderator = 'moderator',
  Gamer = 'gamer',
  Guest = 'guest',
}