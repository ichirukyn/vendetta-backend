import { ErisEnvLoader } from 'eris-env';

const envLoader = new ErisEnvLoader({ logger: true });

export const mainConfig = {
  tokenSecret: envLoader.getEnv('string', 'TOKEN', 'SECRET'),
  jwtLifeTime: envLoader.getEnv('string', 'JWT', 'LIFETIME'),
  database: {
    host: envLoader.getEnv('string', 'DB', 'HOST'),
    port: envLoader.getEnv('number', 'DB', 'PORT'),
    user: envLoader.getEnv('string', 'DB', 'USER'),
    pass: envLoader.getEnv('string', 'DB', 'PASS'),
    name: envLoader.getEnv('string', 'DB', 'NAME'),
  },
  redis: {
    port: envLoader.getEnv('number', 'REDIS', 'PORT'),
    host: envLoader.getEnv('string', 'REDIS', 'HOST'),
    password: envLoader.getEnv('string', 'REDIS', 'PASSWORD'),
  },
};
