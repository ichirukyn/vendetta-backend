import { ForbiddenException, Injectable, InternalServerErrorException } from '@nestjs/common';
import * as jwt from 'jsonwebtoken';
import { User } from '../../../entity/users/user.model';
import { RedisService } from '../../services/redis/redis.service';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { FunctionNames } from '../../enums/functions.enum';
import { Roles } from '../../enums';


export class HttpRequest extends Request {
  public functionName: FunctionNames[] = [];
}

@Injectable()
export class AuthGuard {
  constructor(
    private redisService: RedisService,
    @InjectRepository(User) private usersRepository: Repository<User>,
  ) {
  }
  
  async validateAccess(request: HttpRequest, requiredRole?: Roles): Promise<User> {
    const authHeader = request.headers['authorization']?.toString().split('Bearer ')[1];
    if (!authHeader) throw new ForbiddenException('Не предоставлен токен доступа');
    
    return this.validate(authHeader, requiredRole, request.functionName);
  }
  
  async validate(authHeader: string, requiredRole: Roles, functionName: string[]) {
    
    const decoded = jwt.verify(authHeader, process.env.JWT_LIFETIME, function(err, decoded) {
      if (err) throw new ForbiddenException('Токен неверен');
      
      return decoded;
    });
    
    
    const redisSession = await this.redisService.getByKey(`userToken:${ authHeader }`);
    if (!redisSession) throw new ForbiddenException('Сессия не создана или истекла');
    
    const user = await this.usersRepository.findOneBy({ chat_id: decoded.chat_id });
    if (!user) throw new ForbiddenException('Пользователь не найден или удален');
    
    
    if (requiredRole) {
      // Если переданы список ролей
      let allowed = false;
      
      if (user.role === requiredRole) allowed = true;
      
      if (!allowed) throw new InternalServerErrorException('Недостаточно прав для выполнения');
    }
    
    return user;
  }
}
