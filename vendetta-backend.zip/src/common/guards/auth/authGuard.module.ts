import { Global, Module } from '@nestjs/common';
import { AuthGuard } from './auth.guard';
import { User } from '../../../entity/users/user.model';
import { RedisService } from '../../services/redis/redis.service';
import { TypeOrmModule } from '@nestjs/typeorm';

@Global()
@Module({
  providers: [AuthGuard],
  exports: [AuthGuard],
})
export class AuthGuardModule {
}
